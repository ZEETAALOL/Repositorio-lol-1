package com.holamundo.ejemplo.holamundo.controller;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@RestController
public class HolaMundoController {

    @GetMapping("/hola")
    public String holaMundo() {
        return """
            <!DOCTYPE html>
            <html lang="es">
            <head>
                <meta charset="UTF-8">
                <title>Hola Mundo</title>
                <style>
                    body {
                        background-color: #000;
                        color: #fff;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        height: 100vh;
                        margin: 0;
                        font-family: Arial, sans-serif;
                        text-align: center;
                    }
                    h1 {
                        color: red;
                        font-size: 3rem;
                    }
                </style>
            </head>
            <body>
                <h1>¡HOLA MUNDO!</h1>
            </body>
            </html>
        """;
    }
}